------------------------------------------------------------------------
SF Atarian System - Version 1.0
------------------------------------------------------------------------

The following fonts are included:

 - SF Atarian System
 - SF Atarian System, Italic
 - SF Atarian System, Bold
 - SF Atarian System, Bold Italic
 - SF Atarian System Extended
 - SF Atarian System Extended, Italic
 - SF Atarian System Extended, Bold
 - SF Atarian System Extended, Bold Italic 

------------------------------------------------------------------------
SF Atarian System - Version 1.0 - Features
------------------------------------------------------------------------

 - Includes lowercase and uppercase letters, numbers, and limited
   punctuation.
 - Proper spacing and kerning.

--------------------------------------------------------------------------------------
SF Atarian System - Version 1.0 - Special Characters
--------------------------------------------------------------------------------------

 - Atari Fuji Logo Style a -------------------- press @
 - Atari Fuji Logo Style b -------------------- press #
 - Atari Fuji Logo Style c -------------------- press *

------------------------------------------------------------------------
ShyFonts Freeware Terms of Use
------------------------------------------------------------------------

By downloading this font package you agree to the following terms
of use:

 - This FONT PACKAGE is FREEWARE and may be distributed ONLY via the
   Internet for FREE.  Under NO circumstances may this FONT PACKAGE 
   be sold for a profit nor be included as part of another product or
   CD-ROM compilation.  If you wish to include this FONT PACKAGE for
   FREE distribution on your Web Site, please  include all of the fonts
   and original documentation supplied with this FONT PACKAGE.  For
   the latest releases and updates for this and other FONT PACKAGES,
   check our Web Site at http://www.shyfonts.com/.

 - You may install and use this FONT PACKAGE on an unlimited
   amount of machines.

 - You may NOT rename, edit, or create any alternate variations of
   the fonts included in this FONT PACKAGE.

 - This FONT PACKAGE comes "as is" with NO warranty whatsoever.
   SHYFONTS accepts NO responsibility for any damages or loss of
   any kind due to the use of this FONT PACKAGE.  The use of this
   FONT PACKAGE is solely your responsibility -- you use this FONT
   PACKAGE at your own risk.

If you have any question regarding this document or the usage of
this font package, feel free to contact us at info@shyfonts.com.
Thank you for downloading this font package and enjoy!

ATARI and the FUJI logo are TM and � Hasbro Interactive.
------------------------------------------------------------------------
�1999 ShyFonts Type Foundry -- http://www.shyfonts.com